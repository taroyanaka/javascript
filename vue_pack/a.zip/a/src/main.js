import { createApp } from 'vue'
// import App from './App.vue'
import Foo from './Foo.vue'

// createApp(App).mount('#app')
createApp(Foo).mount('#foo')